package com.www.triptrav.service;

public interface ScheduleRoleService {
    void insertRole(long sco, long uno, int i);
}
