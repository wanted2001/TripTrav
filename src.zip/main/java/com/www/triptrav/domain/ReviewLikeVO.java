package com.www.triptrav.domain;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ReviewLikeVO {
    private long rlId;
    private long rno;
    private long uno;
}
