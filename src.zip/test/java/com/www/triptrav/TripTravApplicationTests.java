package com.www.triptrav;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripTravApplicationTests {

    @Test
    void contextLoads() {
    }

}
